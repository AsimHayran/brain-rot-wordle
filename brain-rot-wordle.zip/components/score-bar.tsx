"use client"

import { motion } from "framer-motion"

// Update the interface to include points
interface ScoreBarProps {
  streak: number
  points: number
}

// Update the component to display points
export default function ScoreBar({ streak, points }: ScoreBarProps) {
  return (
    <motion.div
      className="w-full max-w-sm mx-auto bg-white/20 backdrop-blur-sm rounded-full px-4 py-2 mb-4 flex items-center justify-between"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <div className="flex items-center gap-2">
        <span className="text-white font-bold">Streak:</span>
        <motion.span
          className="text-white font-bold"
          key={`streak-${streak}`}
          initial={{ scale: 1.5 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          {streak}
        </motion.span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-white font-bold">Points:</span>
        <motion.span
          className="text-white font-bold"
          key={`points-${points}`}
          initial={{ scale: 1.5 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 300 }}
        >
          {points}
        </motion.span>
      </div>
      <div className="text-white font-bold">{getStreakMessage(streak)}</div>
    </motion.div>
  )
}

function getStreakMessage(streak: number): string {
  if (streak === 0) return "💀 L RIZZ"
  if (streak < 3) return "🤔 MID"
  if (streak < 5) return "✨ SLAY"
  if (streak < 10) return "🔥 FIRE"
  return "🐐 GOATED"
}

