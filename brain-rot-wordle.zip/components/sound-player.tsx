"use client"

import { useEffect, useRef } from "react"

interface SoundPlayerProps {
  gameStatus: "playing" | "won" | "lost"
  generationalDamage: boolean
  damageTypes: string[]
}

export default function SoundPlayer({ gameStatus, generationalDamage, damageTypes }: SoundPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null)
  const prevStatusRef = useRef(gameStatus)
  const prevDamageRef = useRef(generationalDamage)
  const glitchSoundIntervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Play sound when game status changes
    if (prevStatusRef.current !== gameStatus && audioRef.current) {
      if (gameStatus === "won") {
        audioRef.current.src = "/sounds/win.mp3"
        audioRef.current.play().catch((e) => console.log("Audio play failed:", e))
      } else if (gameStatus === "lost") {
        audioRef.current.src = "/sounds/lose.mp3"
        audioRef.current.play().catch((e) => console.log("Audio play failed:", e))
      }
    }

    // Play sound when generational damage activates
    if (!prevDamageRef.current && generationalDamage && audioRef.current) {
      audioRef.current.src = "/sounds/damage.mp3"
      audioRef.current.play().catch((e) => console.log("Audio play failed:", e))

      // Set up random glitch sounds if visual distortion is active
      if (damageTypes.includes("visualDistortion") || damageTypes.includes("timeWarp")) {
        glitchSoundIntervalRef.current = setInterval(() => {
          if (Math.random() < 0.3 && audioRef.current) {
            audioRef.current.src = "/sounds/glitch.mp3"
            audioRef.current.volume = 0.2
            audioRef.current.play().catch((e) => console.log("Audio play failed:", e))
          }
        }, 5000)
      }
    }

    // Clean up glitch sound interval when damage deactivates
    if (prevDamageRef.current && !generationalDamage && glitchSoundIntervalRef.current) {
      clearInterval(glitchSoundIntervalRef.current)
      glitchSoundIntervalRef.current = null
    }

    prevStatusRef.current = gameStatus
    prevDamageRef.current = generationalDamage

    // Clean up on unmount
    return () => {
      if (glitchSoundIntervalRef.current) {
        clearInterval(glitchSoundIntervalRef.current)
      }
    }
  }, [gameStatus, generationalDamage, damageTypes])

  // Play background music on mount
  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3")
    bgMusic.volume = 0.2
    bgMusic.loop = true

    // Try to play background music (may be blocked by browser)
    const playPromise = bgMusic.play()
    if (playPromise !== undefined) {
      playPromise.catch((e) => console.log("Background music play failed:", e))
    }

    return () => {
      bgMusic.pause()
    }
  }, [])

  return <audio id="soundPlayer" ref={audioRef} className="hidden" />
}

