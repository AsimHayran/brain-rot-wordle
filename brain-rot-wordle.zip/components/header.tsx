"use client"

import { motion } from "framer-motion"

export default function Header() {
  return (
    <motion.div
      className="w-full text-center mb-4"
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <motion.h1
        className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-pink-500 to-blue-500"
        animate={{
          scale: [1, 1.05, 1],
          rotate: [0, 2, -2, 0],
        }}
        transition={{
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          duration: 2,
        }}
      >
        🧠 BRAIN ROT WORDLE 💀
      </motion.h1>
      <p className="text-white text-sm mt-1">Guess the 5-letter word or whatever idk</p>
    </motion.div>
  )
}

