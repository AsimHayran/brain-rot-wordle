"use client"

import { motion, AnimatePresence } from "framer-motion"

interface MemePopupProps {
  text: string
  image: string
}

export default function MemePopup({ text, image }: MemePopupProps) {
  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none"
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.5 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        <div className="bg-black/80 backdrop-blur-md p-6 rounded-xl border-2 border-pink-500 shadow-lg max-w-sm w-full text-center">
          <motion.div
            animate={{
              rotate: [0, -5, 5, -5, 0],
              scale: [1, 1.05, 1, 1.05, 1],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1 }}
          >
            <h3 className="text-2xl font-bold text-white mb-2">{text}</h3>
            {image && (
              <div
                className="w-full h-40 bg-contain bg-center bg-no-repeat"
                style={{ backgroundImage: `url(${image})` }}
              ></div>
            )}
          </motion.div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}

