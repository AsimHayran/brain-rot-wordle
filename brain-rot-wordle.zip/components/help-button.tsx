"use client"

import { motion } from "framer-motion"
import { HelpCircle, Sparkles } from "lucide-react"

interface HelpButtonProps {
  onHelp: () => void
  points: number
  helpUsed: boolean
}

export default function HelpButton({ onHelp, points, helpUsed }: HelpButtonProps) {
  const canUseHelp = points >= 2

  return (
    <motion.button
      onClick={onHelp}
      className={`
        flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm
        ${canUseHelp ? "bg-gradient-to-r from-pink-500 to-purple-500 text-white" : "bg-gray-400 text-gray-200"}
        ${helpUsed ? "opacity-70" : "opacity-100"}
      `}
      whileHover={canUseHelp ? { scale: 1.05 } : {}}
      whileTap={canUseHelp ? { scale: 0.95 } : {}}
      disabled={!canUseHelp}
    >
      <HelpCircle size={16} />
      <span>Help (2 pts)</span>

      {/* Sparkle effects */}
      {canUseHelp && (
        <>
          <motion.div
            className="absolute -top-1 -right-1"
            animate={{
              rotate: [0, 20, 0, -20, 0],
              scale: [1, 1.2, 1, 1.2, 1],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
          >
            <Sparkles size={14} className="text-yellow-300" />
          </motion.div>

          <motion.div
            className="absolute -bottom-1 -left-1"
            animate={{
              rotate: [0, -20, 0, 20, 0],
              scale: [1, 1.2, 1, 1.2, 1],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, delay: 0.5 }}
          >
            <Sparkles size={14} className="text-yellow-300" />
          </motion.div>
        </>
      )}
    </motion.button>
  )
}

