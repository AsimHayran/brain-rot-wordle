"use client"

import { motion } from "framer-motion"

interface KeyboardProps {
  onKeyPress: (key: string) => void
  usedKeys: Record<string, "correct" | "present" | "absent" | undefined>
  generationalDamage: boolean
  damageTypes: string[]
  problemLetters: string[]
}

export default function Keyboard({
  onKeyPress,
  usedKeys,
  generationalDamage,
  damageTypes,
  problemLetters,
}: KeyboardProps) {
  const rows = [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["ENTER", "Z", "X", "C", "V", "B", "N", "M", "BACKSPACE"],
  ]

  return (
    <div className="w-full max-w-md mx-auto mt-4">
      {rows.map((row, rowIndex) => (
        <div key={rowIndex} className="flex justify-center gap-1 my-1">
          {row.map((key) => {
            const isSpecialKey = key === "ENTER" || key === "BACKSPACE"
            const keyState = usedKeys[key]
            const isProblemLetter = problemLetters.includes(key)

            // Determine if this key should have extra glitching
            const shouldExtraGlitch = generationalDamage && isProblemLetter

            // Calculate random offsets for keyboard drift
            const hasDrift = generationalDamage && damageTypes.includes("keyGlitch")
            const driftX = hasDrift ? Math.random() * 10 - 5 : 0
            const driftY = hasDrift ? Math.random() * 10 - 5 : 0

            return (
              <motion.button
                key={key}
                onClick={() => onKeyPress(key)}
                className={`
                  ${isSpecialKey ? "px-3" : "px-2"} py-4 rounded-lg font-bold text-sm
                  ${keyState === "correct" ? "bg-green-500 text-white" : ""}
                  ${keyState === "present" ? "bg-yellow-500 text-white" : ""}
                  ${keyState === "absent" ? "bg-gray-700 text-white" : ""}
                  ${!keyState ? "bg-gray-200 text-black" : ""}
                  ${generationalDamage ? "border border-red-500" : ""}
                  ${shouldExtraGlitch ? "shadow-[0_0_8px_rgba(255,0,0,0.7)]" : ""}
                  transition-colors duration-300 relative overflow-hidden
                `}
                style={{
                  transform: hasDrift ? `translate(${driftX}px, ${driftY}px)` : undefined,
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                animate={
                  shouldExtraGlitch
                    ? {
                        x: [0, -3, 3, -3, 0],
                        y: [0, -3, 3, -3, 0],
                        rotate: [0, -2, 2, -2, 0],
                      }
                    : generationalDamage && damageTypes.includes("keyGlitch")
                      ? {
                          x: Math.random() < 0.3 ? [0, -2, 2, 0] : 0,
                          y: Math.random() < 0.3 ? [0, -2, 2, 0] : 0,
                        }
                      : {}
                }
                transition={{
                  repeat:
                    shouldExtraGlitch || (generationalDamage && damageTypes.includes("keyGlitch"))
                      ? Number.POSITIVE_INFINITY
                      : 0,
                  repeatType: "mirror",
                  duration: shouldExtraGlitch ? 0.2 : 0.3,
                  repeatDelay: shouldExtraGlitch ? 0.1 : Math.random() * 2,
                }}
              >
                {key === "BACKSPACE" ? "⌫" : key}

                {/* Visual glitch effect for problem letters */}
                {shouldExtraGlitch && (
                  <>
                    <motion.div
                      className="absolute inset-0 bg-red-500 mix-blend-overlay"
                      animate={{ opacity: [0, 0.3, 0] }}
                      transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.5, repeatType: "mirror" }}
                    />
                    <motion.div
                      className="absolute inset-0 border-2 border-red-500 rounded-lg"
                      animate={{ opacity: [0, 1, 0] }}
                      transition={{ repeat: Number.POSITIVE_INFINITY, duration: 0.3 }}
                    />
                  </>
                )}

                {/* Visual distortion effect */}
                {generationalDamage && damageTypes.includes("visualDistortion") && (
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent mix-blend-overlay"
                    animate={{
                      left: ["-100%", "100%"],
                    }}
                    transition={{
                      repeat: Number.POSITIVE_INFINITY,
                      duration: 1.5,
                      repeatDelay: Math.random() * 3,
                    }}
                  />
                )}
              </motion.button>
            )
          })}
        </div>
      ))}
    </div>
  )
}

