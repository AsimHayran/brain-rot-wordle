"use client"

import { useState, useEffect } from "react"
import GameGrid from "./game-grid"
import Keyboard from "./keyboard"
import Header from "./header"
import ScoreBar from "./score-bar"
import MemePopup from "./meme-popup"
import SoundPlayer from "./sound-player"
import AuraLevel from "./aura-level"
import HelpButton from "./help-button"
import { WORDS } from "@/lib/words"
import RestartButton from "./restart-button"

// Define different types of generational damage
type DamageType = "keyGlitch" | "letterSwap" | "visualDistortion" | "timeWarp" | "invertedControls"

export default function GameContainer() {
  const [currentWord, setCurrentWord] = useState("")
  const [guesses, setGuesses] = useState<string[]>([])
  const [currentGuess, setCurrentGuess] = useState("")
  const [gameStatus, setGameStatus] = useState<"playing" | "won" | "lost">("playing")
  const [showMeme, setShowMeme] = useState(false)
  const [memeContent, setMemeContent] = useState({ text: "", image: "" })
  const [streak, setStreak] = useState(0)
  const [usedKeys, setUsedKeys] = useState<Record<string, "correct" | "present" | "absent" | undefined>>({})
  const [points, setPoints] = useState(0)
  const [auraLevel, setAuraLevel] = useState(0)
  const [generationalDamage, setGenerationalDamage] = useState(false)
  const [helpUsed, setHelpUsed] = useState(false)
  const [revealedLetters, setRevealedLetters] = useState<number[]>([])
  const [damageTypes, setDamageTypes] = useState<DamageType[]>([])
  const [problemLetters, setProblemLetters] = useState<string[]>([])

  // Initialize game
  useEffect(() => {
    // Get random word from list
    const randomIndex = Math.floor(Math.random() * WORDS.length)
    setCurrentWord(WORDS[randomIndex].toUpperCase())

    // Load streak, points and aura from localStorage
    const savedStreak = localStorage.getItem("brainrot-streak")
    if (savedStreak) {
      setStreak(Number.parseInt(savedStreak))
    }

    const savedPoints = localStorage.getItem("brainrot-points")
    if (savedPoints) {
      setPoints(Number.parseInt(savedPoints))
    } else {
      // Initialize with 100 points for new players
      setPoints(100)
      localStorage.setItem("brainrot-points", "100")
    }

    const savedAura = localStorage.getItem("brainrot-aura")
    if (savedAura) {
      setAuraLevel(Number.parseInt(savedAura))
    }
  }, [])

  // Effect for generational damage
  useEffect(() => {
    // If aura level drops below -5, activate generational damage
    if (auraLevel < -5 && !generationalDamage) {
      setGenerationalDamage(true)

      // Select random damage types based on how negative the aura is
      const numDamageTypes = Math.min(5, Math.floor(Math.abs(auraLevel) / 2))
      const allDamageTypes: DamageType[] = [
        "keyGlitch",
        "letterSwap",
        "visualDistortion",
        "timeWarp",
        "invertedControls",
      ]
      const selectedDamageTypes: DamageType[] = []

      // Always include keyGlitch
      selectedDamageTypes.push("keyGlitch")

      // Add other random damage types
      const remainingTypes = allDamageTypes.filter((type) => type !== "keyGlitch")
      for (let i = 0; i < numDamageTypes - 1 && i < remainingTypes.length; i++) {
        const randomIndex = Math.floor(Math.random() * remainingTypes.length)
        selectedDamageTypes.push(remainingTypes[randomIndex])
        remainingTypes.splice(randomIndex, 1)
      }

      setDamageTypes(selectedDamageTypes)
      showRandomMeme(`GENERATIONAL DAMAGE ACTIVATED: ${selectedDamageTypes.length} TYPES 💀💀💀`)
    } else if (auraLevel >= -5 && generationalDamage) {
      setGenerationalDamage(false)
      setDamageTypes([])
    }
  }, [auraLevel])

  // Track problem letters (letters not guessed correctly after 2 rounds)
  useEffect(() => {
    if (guesses.length >= 2) {
      // Get all letters that have been guessed
      const allGuessedLetters = new Set<string>()
      guesses.forEach((guess) => {
        guess.split("").forEach((letter) => {
          allGuessedLetters.add(letter)
        })
      })

      // Find letters in the word that haven't been guessed correctly
      const newProblemLetters = currentWord.split("").filter((letter) => {
        // Check if this letter has been guessed correctly in any position
        let correctlyGuessed = false
        guesses.forEach((guess) => {
          for (let i = 0; i < guess.length; i++) {
            if (guess[i] === letter && currentWord[i] === letter) {
              correctlyGuessed = true
              break
            }
          }
        })

        // It's a problem letter if it's been guessed but not correctly placed
        return allGuessedLetters.has(letter) && !correctlyGuessed
      })

      setProblemLetters(newProblemLetters)
    }
  }, [guesses, currentWord])

  // Add physical keyboard support
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (gameStatus !== "playing") return

      // Convert key to uppercase for consistency
      let key = event.key.toUpperCase()

      // Apply inverted controls damage if active
      if (generationalDamage && damageTypes.includes("invertedControls")) {
        if (/^[A-Z]$/.test(key)) {
          // Get the opposite letter in the alphabet
          const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
          const index = alphabet.indexOf(key)
          if (index !== -1) {
            key = alphabet[25 - index]
          }
        }
      }

      // Map Enter and Backspace keys
      if (key === "ENTER") {
        handleKeyPress("ENTER")
      } else if (key === "BACKSPACE" || key === "DELETE" || key === "ARROWLEFT") {
        handleKeyPress("BACKSPACE")
      } else if (/^[A-Z]$/.test(key)) {
        // Only handle A-Z keys
        handleKeyPress(key)
      }
    }

    // Add event listener
    window.addEventListener("keydown", handleKeyDown)

    // Clean up
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [gameStatus, currentGuess, generationalDamage, damageTypes]) // Re-add listeners when these change

  // Handle keyboard input
  const handleKeyPress = (key: string) => {
    if (gameStatus !== "playing") return

    // Play sound
    const soundPlayer = document.getElementById("soundPlayer") as HTMLAudioElement
    if (soundPlayer) {
      soundPlayer.src = "/sounds/key-press.mp3"
      soundPlayer.play().catch((e) => console.log("Audio play failed:", e))
    }

    // Apply key glitch damage effect (random chance of wrong key)
    if (
      generationalDamage &&
      damageTypes.includes("keyGlitch") &&
      Math.random() < 0.2 &&
      key !== "ENTER" &&
      key !== "BACKSPACE"
    ) {
      // 20% chance to press a random key instead
      const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
      key = alphabet[Math.floor(Math.random() * alphabet.length)]
    }

    if (key === "ENTER") {
      if (currentGuess.length !== 5) return

      // Apply letter swap damage if active
      let finalGuess = currentGuess
      if (generationalDamage && damageTypes.includes("letterSwap") && Math.random() < 0.3) {
        // 30% chance to swap two random letters
        const letters = finalGuess.split("")
        const pos1 = Math.floor(Math.random() * letters.length)
        let pos2 = Math.floor(Math.random() * letters.length)
        while (pos2 === pos1) {
          pos2 = Math.floor(Math.random() * letters.length)
        }

        // Swap the letters
        const temp = letters[pos1]
        letters[pos1] = letters[pos2]
        letters[pos2] = temp

        finalGuess = letters.join("")
        showRandomMeme(`LETTERS SWAPPED: ${currentGuess} → ${finalGuess} 🔄`)
      }

      // Add guess to list regardless of whether it's in the wordlist
      const newGuesses = [...guesses, finalGuess]
      setGuesses(newGuesses)

      // Update keyboard colors
      updateUsedKeys(finalGuess)

      // Check if won or lost
      if (finalGuess === currentWord) {
        setGameStatus("won")

        // Add points when player wins - different amounts based on if help was used
        const pointsToAdd = helpUsed ? 1 : 10
        const newPoints = points + pointsToAdd
        setPoints(newPoints)
        localStorage.setItem("brainrot-points", newPoints.toString())

        // Increase aura level on win
        const newAura = auraLevel + 2
        setAuraLevel(newAura)
        localStorage.setItem("brainrot-aura", newAura.toString())

        setStreak((prev) => {
          const newStreak = prev + 1
          localStorage.setItem("brainrot-streak", newStreak.toString())
          return newStreak
        })

        // Show different message based on if help was used
        if (helpUsed) {
          showRandomMeme("CARRIED BY HELP BUT OK 💅")
        } else {
          showRandomMeme("SLAY QUEEN! 💅✨")
        }

        // Auto restart after 3 seconds
        setTimeout(() => {
          resetGame()
        }, 3000)
      } else if (newGuesses.length >= 6) {
        setGameStatus("lost")
        localStorage.setItem("brainrot-streak", "0")
        setStreak(0)

        // Decrease aura level on loss
        const newAura = auraLevel - 3
        setAuraLevel(newAura)
        localStorage.setItem("brainrot-aura", newAura.toString())

        showRandomMeme(`L BOZO! THE WORD WAS ${currentWord} 💀`)

        // Auto restart after 3 seconds
        setTimeout(() => {
          resetGame()
        }, 3000)
      } else {
        // Calculate how many letters were correct
        let correctCount = 0
        for (let i = 0; i < finalGuess.length; i++) {
          if (finalGuess[i] === currentWord[i]) {
            correctCount++
          }
        }

        // Adjust aura based on guess quality
        if (correctCount >= 3) {
          // Good guess, increase aura slightly
          setAuraLevel((prev) => {
            const newAura = prev + 1
            localStorage.setItem("brainrot-aura", newAura.toString())
            return newAura
          })
        } else if (correctCount === 0) {
          // Bad guess, decrease aura
          setAuraLevel((prev) => {
            const newAura = prev - 1
            localStorage.setItem("brainrot-aura", newAura.toString())
            return newAura
          })
        }

        // Show random meme after each guess
        showRandomMeme()
      }

      setCurrentGuess("")
    } else if (key === "BACKSPACE") {
      setCurrentGuess((prev) => prev.slice(0, -1))
    } else if (/^[A-Z]$/.test(key) && currentGuess.length < 5) {
      setCurrentGuess((prev) => prev + key)
    }
  }

  const updateUsedKeys = (guess: string) => {
    const newUsedKeys = { ...usedKeys }

    for (let i = 0; i < guess.length; i++) {
      const letter = guess[i]

      if (letter === currentWord[i]) {
        newUsedKeys[letter] = "correct"
      } else if (currentWord.includes(letter) && newUsedKeys[letter] !== "correct") {
        newUsedKeys[letter] = "present"
      } else if (!currentWord.includes(letter)) {
        newUsedKeys[letter] = "absent"
      }
    }

    setUsedKeys(newUsedKeys)
  }

  const showRandomMeme = (text?: string) => {
    const memes = [
      { text: text || "That was NOT giving 💅", image: "/memes/not-giving.gif" },
      { text: text || "Based 🤓", image: "/memes/based.gif" },
      { text: text || "Skill issue tbh", image: "/memes/skill-issue.gif" },
      { text: text || "Literally me fr fr", image: "/memes/literally-me.gif" },
      { text: text || "No cap frfr", image: "/memes/no-cap.gif" },
      { text: text || "Rizz level: ZERO", image: "/memes/rizz.gif" },
    ]

    const randomMeme = memes[Math.floor(Math.random() * memes.length)]
    setMemeContent(randomMeme)
    setShowMeme(true)

    // Hide meme after 2 seconds
    setTimeout(() => {
      setShowMeme(false)
    }, 2000)
  }

  const resetGame = () => {
    const randomIndex = Math.floor(Math.random() * WORDS.length)
    setCurrentWord(WORDS[randomIndex].toUpperCase())
    setGuesses([])
    setCurrentGuess("")
    setGameStatus("playing")
    setUsedKeys({})
    setHelpUsed(false)
    setRevealedLetters([])
    setProblemLetters([])
  }

  // Add this new function for manual restarts
  const handleRestart = () => {
    // Show a meme when restarting
    showRandomMeme("RESTARTING... NEW WORD INCOMING 🔄")

    // Reset the game but preserve points
    resetGame()
  }

  const handleHelp = () => {
    // Check if player has enough points
    if (points < 2) {
      showRandomMeme("NOT ENOUGH POINTS BROKE BOY 💀")
      return
    }

    // Deduct points
    const newPoints = points - 2
    setPoints(newPoints)
    localStorage.setItem("brainrot-points", newPoints.toString())

    // Mark that help was used in this game
    setHelpUsed(true)

    // Find a letter position that hasn't been revealed yet
    const unrevealed = Array.from({ length: 5 }, (_, i) => i).filter((pos) => !revealedLetters.includes(pos))

    if (unrevealed.length === 0) {
      // All letters have been revealed already
      showRandomMeme("ALL LETTERS ALREADY REVEALED 🤡")
      return
    }

    // Randomly select one of the unrevealed positions
    const posToReveal = unrevealed[Math.floor(Math.random() * unrevealed.length)]

    // Add this position to revealed letters
    setRevealedLetters([...revealedLetters, posToReveal])

    // Update current guess with the revealed letter
    const newGuess = currentGuess.split("")
    newGuess[posToReveal] = currentWord[posToReveal]
    setCurrentGuess(newGuess.join(""))

    showRandomMeme(`REVEALED LETTER: ${currentWord[posToReveal]} 🔮`)
  }

  return (
    <div className="w-full max-w-md mx-auto flex flex-col items-center gap-4">
      <Header />
      <ScoreBar streak={streak} points={points} />
      <div className="w-full flex justify-between items-center">
        <AuraLevel auraLevel={auraLevel} generationalDamage={generationalDamage} damageTypes={damageTypes} />
        <RestartButton onRestart={handleRestart} />
      </div>
      <GameGrid
        guesses={guesses}
        currentGuess={currentGuess}
        currentWord={currentWord}
        gameStatus={gameStatus}
        generationalDamage={generationalDamage}
        revealedLetters={revealedLetters}
        damageTypes={damageTypes}
      />
      <div className="w-full flex justify-between items-center">
        <HelpButton onHelp={handleHelp} points={points} helpUsed={helpUsed} />
        {helpUsed && (
          <div className="text-xs text-white bg-pink-500/70 px-3 py-1 rounded-full">Help used: +1 point if won</div>
        )}
      </div>
      <Keyboard
        onKeyPress={handleKeyPress}
        usedKeys={usedKeys}
        generationalDamage={generationalDamage}
        damageTypes={damageTypes}
        problemLetters={problemLetters}
      />

      {showMeme && <MemePopup text={memeContent.text} image={memeContent.image} />}

      {gameStatus === "lost" && (
        <div className="mt-2 text-xl font-bold text-white bg-black/50 px-4 py-2 rounded-full">
          Word was: {currentWord}
        </div>
      )}

      {gameStatus !== "playing" && <div className="mt-2 text-sm text-white">Game will restart in 3 seconds...</div>}

      <SoundPlayer gameStatus={gameStatus} generationalDamage={generationalDamage} damageTypes={damageTypes} />
    </div>
  )
}

