"use client"

import { motion } from "framer-motion"
import { RefreshCw } from "lucide-react"

interface RestartButtonProps {
  onRestart: () => void
}

export default function RestartButton({ onRestart }: RestartButtonProps) {
  return (
    <motion.button
      onClick={onRestart}
      className="flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm bg-gradient-to-r from-blue-500 to-purple-500 text-white"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
    >
      <RefreshCw size={16} className="animate-spin-slow" />
      <span>New Word</span>

      {/* Random glitch effect */}
      <motion.div
        className="absolute inset-0 bg-white/20 rounded-full"
        animate={{
          opacity: [0, 0.5, 0],
        }}
        transition={{
          repeat: Number.POSITIVE_INFINITY,
          duration: 2,
          repeatDelay: 1,
        }}
      />
    </motion.button>
  )
}

