"use client"

import { motion } from "framer-motion"

interface GameGridProps {
  guesses: string[]
  currentGuess: string
  currentWord: string
  gameStatus: "playing" | "won" | "lost"
  generationalDamage: boolean
  revealedLetters: number[]
  damageTypes: string[]
}

export default function GameGrid({
  guesses,
  currentGuess,
  currentWord,
  gameStatus,
  generationalDamage,
  revealedLetters,
  damageTypes,
}: GameGridProps) {
  // Create array of 6 rows (max guesses)
  const rows = Array(6).fill(null)

  // Visual distortion effect for the entire grid
  const hasVisualDistortion = generationalDamage && damageTypes.includes("visualDistortion")

  return (
    <div
      className={`grid grid-rows-6 gap-2 w-full max-w-sm mx-auto relative ${hasVisualDistortion ? "overflow-hidden" : ""}`}
    >
      {/* Visual distortion overlay */}
      {hasVisualDistortion && (
        <>
          <motion.div
            className="absolute inset-0 bg-gradient-to-b from-transparent via-red-500/10 to-transparent pointer-events-none z-10"
            animate={{
              opacity: [0, 0.5, 0],
              y: [-20, 20],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2, repeatType: "mirror" }}
          />
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-500/10 to-transparent pointer-events-none z-10"
            animate={{
              opacity: [0, 0.3, 0],
              x: [-20, 20],
            }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 3, repeatType: "mirror" }}
          />
        </>
      )}

      {rows.map((_, rowIndex) => {
        // Determine what to render in this row
        const isCurrentRow = rowIndex === guesses.length
        const isCompletedRow = rowIndex < guesses.length

        let rowContent = ""
        if (isCompletedRow) {
          rowContent = guesses[rowIndex]
        } else if (isCurrentRow) {
          rowContent = currentGuess.padEnd(5)
        } else {
          rowContent = "     " // Empty row
        }

        // If game is lost and this is the next row, show the correct word
        if (gameStatus === "lost" && rowIndex === guesses.length) {
          rowContent = currentWord
        }

        // Time warp effect - make the current row shake more
        const hasTimeWarp = generationalDamage && damageTypes.includes("timeWarp") && isCurrentRow

        return (
          <motion.div
            key={rowIndex}
            className="grid grid-cols-5 gap-2"
            animate={
              hasTimeWarp
                ? {
                    scale: [1, 1.02, 0.98, 1],
                    rotate: [0, 1, -1, 0],
                  }
                : {}
            }
            transition={
              hasTimeWarp
                ? {
                    repeat: Number.POSITIVE_INFINITY,
                    duration: 0.5,
                    repeatType: "mirror",
                  }
                : {}
            }
          >
            {rowContent.split("").map((letter, colIndex) => {
              // Determine cell state for completed rows
              let cellState = ""
              if (isCompletedRow) {
                if (letter === currentWord[colIndex]) {
                  cellState = "correct"
                } else if (currentWord.includes(letter)) {
                  cellState = "present"
                } else {
                  cellState = "absent"
                }
              }

              // If showing the answer, all cells should be correct
              if (gameStatus === "lost" && rowIndex === guesses.length) {
                cellState = "correct"
              }

              // Check if this letter was revealed by help
              const isRevealed = isCurrentRow && revealedLetters.includes(colIndex)

              return (
                <motion.div
                  key={colIndex}
                  className={`
                    w-full aspect-square flex items-center justify-center text-2xl font-bold rounded-md border-2 relative
                    ${!letter.trim() ? "border-gray-400 bg-transparent" : ""}
                    ${isCurrentRow && letter.trim() && gameStatus === "playing" && !isRevealed ? "border-white bg-white/20 text-white" : ""}
                    ${isRevealed ? "border-pink-500 bg-pink-500/50 text-white" : ""}
                    ${cellState === "correct" ? "border-green-500 bg-green-500 text-white" : ""}
                    ${cellState === "present" ? "border-yellow-500 bg-yellow-500 text-white" : ""}
                    ${cellState === "absent" ? "border-gray-700 bg-gray-700 text-white" : ""}
                    ${generationalDamage && isCurrentRow ? "border-red-500 shadow-[0_0_10px_rgba(255,0,0,0.5)]" : ""}
                  `}
                  initial={
                    isCompletedRow || (gameStatus === "lost" && rowIndex === guesses.length)
                      ? { scale: 0 }
                      : { scale: 1 }
                  }
                  animate={{
                    scale: 1,
                    rotate:
                      isCompletedRow || (gameStatus === "lost" && rowIndex === guesses.length)
                        ? [0, -10, 10, -10, 0]
                        : generationalDamage && isCurrentRow && letter.trim()
                          ? [0, -3, 3, -3, 0]
                          : isRevealed
                            ? [0, -5, 5, -5, 0]
                            : 0,
                  }}
                  transition={{
                    type: "spring",
                    stiffness: 300,
                    damping: 15,
                    delay:
                      isCompletedRow || (gameStatus === "lost" && rowIndex === guesses.length) ? colIndex * 0.1 : 0,
                    repeat:
                      (generationalDamage && isCurrentRow && letter.trim()) || isRevealed
                        ? Number.POSITIVE_INFINITY
                        : 0,
                    repeatDelay: isRevealed ? 1 : 0.5,
                  }}
                  whileHover={isCurrentRow && letter.trim() && gameStatus === "playing" ? { scale: 1.1 } : {}}
                >
                  {letter}
                  {isRevealed && (
                    <motion.div
                      className="absolute inset-0 border-2 border-pink-500 rounded-md"
                      animate={{ opacity: [0, 0.5, 0] }}
                      transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
                    />
                  )}

                  {/* Visual distortion effect for cells */}
                  {hasVisualDistortion && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent mix-blend-overlay"
                      animate={{
                        left: ["-100%", "100%"],
                      }}
                      transition={{
                        repeat: Number.POSITIVE_INFINITY,
                        duration: 2,
                        repeatDelay: Math.random() * 2,
                      }}
                    />
                  )}
                </motion.div>
              )
            })}
          </motion.div>
        )
      })}
    </div>
  )
}

